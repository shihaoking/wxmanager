<?php
/**
 * [WeEngine System] Copyright (c) 2013 WE7.CC
 * $sn: htdocs/payment/wechat/native.php : v 1ced5ce4bed8 : 2014/03/19 08:35:31 : veryinf $
 */
define('IN_MOBILE', true);
require '../../source/bootstrap.inc.php';
message('支付失败, 请稍后重试.');
