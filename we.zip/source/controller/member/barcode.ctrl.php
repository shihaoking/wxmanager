<?php 
/**
 * [WeEngine System] Copyright (c) 2013 WE7.CC
 */
defined('IN_IA') or exit('Access Denied');

message('二维码管理可以针对不同推广渠道生成不同类型的二维码, 方便进行统计分析. 此功能正在开发中, 近两日会通过自动更新功能发布.');