<?php 
/**
 * [WeEngine System] Copyright (c) 2013 WE7.CC
 */
defined('IN_IA') or exit('Access Denied');
include model('rule');

$eid = intval($_GPC['eid']);
$sql = 'SELECT * FROM ' . tablename('modules_bindings') . ' WHERE `eid`=:eid';
$entry = pdo_fetch($sql, array(':eid' => $eid));
if(empty($entry)) {
	message('非法访问.');
}

$modulename = '';
foreach($_W['account']['modules'] as $m) {
	if($m['name'] == $entry['module']) {
		$modulename = $m['name'];
		break;
	}
}
if (empty($modulename)) {
	message('您未启用、安装该模块或是您没有权限使用！', '', 'error');
}

$reply = pdo_fetch("SELECT * FROM " . tablename('cover_reply') . ' WHERE `module` = :module AND `do` = :do AND weid = :weid', array(':module' => $entry['module'], ':do' => $entry['do'], ':weid' => $_W['weid']));
$rule = rule_single($reply['rid']);
$rule['keywords'] = array();
if(is_array($rule['keyword'])) {
	foreach($rule['keyword'] as $kwd) {
		$rule['keywords'][] = $kwd['content'];
	}
}
$rule['keywords'] = implode(',', $rule['keywords']);
if(empty($reply)) {
	$reply = array();
}
if(empty($reply['title'])) {
	$reply['title'] = $entry['title'];
}

if (checksubmit('submit')) {
	if(trim($_GPC['keywords']) == '') {
		message('必须输入触发关键字.');
	}
	if(trim($_GPC['title']) == '') {
		message('必须输入封面标题和链接.');
	}
	$record = array(
		'weid' => $_W['weid'],
		'cid' => '',
		'name' => $entry['title'],
		'module' => 'cover',
		'status' => intval($_GPC['status']),
	);
	if (!empty($_GPC['istop'])) {
		$record['displayorder'] = 255;
	} else {
		$record['displayorder'] = intval($_GPC['displayorder']) > 254 ? 254 : intval($_GPC['displayorder']);
	}
	
	$rid = $reply['rid'];
	if (!empty($rule['rule'])) {
		pdo_update('rule', $record, array('id' => $rid));
	} else {
		pdo_insert('rule', $record);
		$rid = pdo_insertid();
	}
	
	if (!empty($rid)) {
		//更新，添加，删除关键字
		$sql = 'DELETE FROM '. tablename('rule_keyword') . ' WHERE `rid`=:rid AND `weid`=:weid';
		$pars = array();
		$pars[':rid'] = $rid;
		$pars[':weid'] = $_W['weid'];
		pdo_query($sql, $pars);
		
		$rows = array();
		$rowtpl = array(
			'rid' => $rid,
			'weid' => $_W['weid'],
			'module' => $record['module'],
			'status' => $record['status'],
			'displayorder' => $record['displayorder'],
		);
		if(!empty($_GPC['keywords'])) {
			$kwds = explode(',', trim($_GPC['keywords']));
			foreach($kwds as $kwd) {
				$kwd = trim($kwd);
				if(empty($kwd)) {
					continue;
				}
				$rowtpl['content'] = $kwd;
				$rowtpl['type'] = 1;
				$rows[md5($rowtpl['type'] . $rowtpl['content'])] = $rowtpl;
			}
		}
		foreach($rows as $krow) {
			$result = pdo_insert('rule_keyword', $krow);
		}
		$data = array(
			'weid' => $_W['weid'],
			'rid' => $rid,
			'title' => $_GPC['title'],
			'description' => $_GPC['description'],
			'thumb' => $_GPC['thumb'],
			'url' => $_GPC['url'],
			'do' => $entry['do'],
			'module' => $entry['module'],
		);
		if (empty($reply['id'])) {
			pdo_insert('cover_reply', $data);
		} else {
			unset($data['rid']);
			pdo_update('cover_reply', $data, array('rid' => $rid));
		}
		message('封面保存成功！', 'refresh', 'success');
	} else {
		message('封面保存失败, 请联系网站管理员！');
	}
}
template('rule/cover');
