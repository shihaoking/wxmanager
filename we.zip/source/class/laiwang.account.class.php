<?php
/**
 * 微擎公号核心类
 *
 * [WeEngine System] Copyright (c) 2013 WE7.CC
 */
defined('IN_IA') or exit('Access Denied');

class WeAccount {
	
	public function __construct() {
	}

}
